#ifndef NODO_H
#define NODO_H

typedef struct Nodo
{
	char *dato;
	struct Nodo *next;
}Nodo;

#endif